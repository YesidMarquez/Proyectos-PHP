
<!DOCTYPE html>
<html>
<head>
	<title>CRUD 1.0</title>
</head>
<body>
	<div>
		<center>

			
			<fieldset>
			  
			  <h1>CRUD</h1>
			  	<FORM ACTION="conectar_bd_insert.php" METHOD="POST">

				Ingrese el Nombre: <INPUT TYPE="text" NAME="Nombre"><br><br>
				Ingrese el Apellido: <INPUT TYPE="text" NAME="Apellido"><br><br>
				Ingrese el Nickname: <INPUT TYPE="text" NAME="Nickname"><br><br>
				Ingrese el Estado: <INPUT TYPE="text" NAME="Estado"><br><br>
				<INPUT TYPE="submit" VALUE="Insertar"><br><br>
				</FORM>
				<form ACTION="menu.html">
				<INPUT TYPE="button" VALUE="Retornar al menu"><br><br></form>


			</fieldset>
		</center>
	</div>

</body>
</html>
