<?php
$Numero=0;
$Total=0;
$cont=0;
$suma=0;
for ($Numero=0; $Numero < 100 ; $Numero++){
	if ($Numero % 2 ){

		$suma =$suma+ $Numero;
		$Numero++-1;
					//echo "El numero <br /> ";
			
		echo "El numero ".$suma;	//$cont
		
	} 
	else {
	
	}
	



} 	
	

				# code...
	
	# co0e...




?>