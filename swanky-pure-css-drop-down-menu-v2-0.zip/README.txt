A Pen created at CodePen.io. You can find this one at http://codepen.io/jcoulterdesign/pen/qdWxEm.

 Pure CSS Drop down menu. Nice little addition to any non-javascript user interface. Uses the labels for trick to toggle animations.