<?php
	define('DOMINIO', 'midominio.com.sv');
	define('DN', 'dc=midominio,dc=com,dc=sv');
?>
